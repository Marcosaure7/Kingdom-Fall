create definer = magou277@`%` view ennemidropview as
select `e`.`id`                                                                     AS `ennemi_id`,
       `e`.`nom`                                                                    AS `ennemi_nom`,
       json_arrayagg((case when (`ed`.`drop_type` = 'arme') then `a`.`nom` end))    AS `armes`,
       json_arrayagg((case when (`ed`.`drop_type` = 'armure') then `ar`.`nom` end)) AS `armures`,
       json_arrayagg((case when (`ed`.`drop_type` = 'potion') then `p`.`nom` end))  AS `potions`,
       json_arrayagg((case when (`ed`.`drop_type` = 'divers') then `d`.`nom` end))  AS `divers`
from (((((`rpg_game`.`ennemis` `e` left join `rpg_game`.`ennemi_drops` `ed`
          on ((`e`.`id` = `ed`.`ennemi_id`))) left join `rpg_game`.`armes` `a`
         on (((`ed`.`drop_id` = `a`.`id`) and (`ed`.`drop_type` = 'arme')))) left join `rpg_game`.`armures` `ar`
        on (((`ed`.`drop_id` = `ar`.`id`) and (`ed`.`drop_type` = 'armure')))) left join `rpg_game`.`potions` `p`
       on (((`ed`.`drop_id` = `p`.`id`) and (`ed`.`drop_type` = 'potion')))) left join `rpg_game`.`divers` `d`
      on (((`ed`.`drop_id` = `d`.`id`) and (`ed`.`drop_type` = 'divers'))))
group by `e`.`id`;

